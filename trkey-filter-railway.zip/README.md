# Trkey Filter Bot on Railway

## How to Deploy
1. Push this project to GitHub.
2. Go to [Railway](https://railway.app) → New Project → Deploy from GitHub.
3. Add the following variables in Railway dashboard:
    - `API_ID`
    - `API_HASH`
    - `BOT_TOKEN`
4. Make sure the Start Command is:
    ```bash
    python3 main.py
    ```
